import { useCallback, useEffect, useRef, useState } from "react";
import type { TrackAudioSchema, TrackSample } from "../types/audio";
import { getSampleBuffer } from "../utils/audioManager";
import {
  getAudioContext,
  resumeAudioContext,
} from "../utils/audioContextSetup";
import { useLoopSettings } from "../context/LoopSettingsContext";

export type PlaybackSample = TrackSample;

export interface UseAudioPlaybackResult {
  playNow(samples: PlaybackSample[], bpm: number): Promise<void>;
  stopAll(): void;
  trackAudioSchema: TrackAudioSchema;
  updateTrackAudioSchema: <K extends keyof TrackAudioSchema>(
    key: K,
    updater: (prev: TrackAudioSchema[K]) => TrackAudioSchema[K]
  ) => void;
  updateAudioNodeParam: (
    type: "gain" | "pan" | "lowpass" | "highpass",
    trackId: number,
    value: number
  ) => void;
}

export default function useAudioPlayback(): UseAudioPlaybackResult {
  const audioContext = getAudioContext();
  const { beatsPerLoop } = useLoopSettings();
  const playingSources = useRef<AudioBufferSourceNode[]>([]);

  const [trackAudioSchema, setTrackAudioSchema] = useState<TrackAudioSchema>({
    filters: useRef(new Map<string, AudioNode>()),
    frequencies: {},
    highpassFrequencies: {},
    gains: {},
    pans: {},
    bypasses: { lowpass: {}, highpass: {} },
  });

  useEffect(() => {
    // Initialize default values for each track if not already present
    const allTrackIds = Array.from({ length: 8 }, (_, i) => i + 1); // or pull from elsewhere
    setTrackAudioSchema((prev) => {
      const updated = { ...prev };
      for (const id of allTrackIds) {
        if (!(id in updated.gains)) updated.gains[id] = 1;
        if (!(id in updated.pans)) updated.pans[id] = 0;
        if (!(id in updated.frequencies)) updated.frequencies[id] = 5000;
        if (!(id in updated.highpassFrequencies))
          updated.highpassFrequencies[id] = 80;
        if (!(id in updated.bypasses.lowpass))
          updated.bypasses.lowpass[id] = false;
        if (!(id in updated.bypasses.highpass))
          updated.bypasses.highpass[id] = false;
      }
      return updated;
    });
  }, []);

  const updateAudioNodeParam = (
    type: "gain" | "pan" | "lowpass" | "highpass",
    trackId: number,
    value: number
  ) => {
    const key = `${trackId}_${type}`;
    const node = trackAudioSchema.filters.current?.get(key);

    if (type === "gain" && node instanceof GainNode) {
      node.gain.setValueAtTime(value, audioContext.currentTime);
    } else if (type === "pan" && node instanceof StereoPannerNode) {
      node.pan.setValueAtTime(value, audioContext.currentTime);
    } else if (
      (type === "lowpass" || type === "highpass") &&
      node instanceof BiquadFilterNode
    ) {
      node.frequency.setValueAtTime(value, audioContext.currentTime);
    } else {
      console.warn(`Node not found or mismatched type for ${key}`);
    }
  };

  const updateTrackAudioSchema = useCallback(
    <K extends keyof TrackAudioSchema>(
      key: K,
      updater: (prev: TrackAudioSchema[K]) => TrackAudioSchema[K]
    ) => {
      console.log(`Updating ${key}`, "Current state:", trackAudioSchema);
      setTrackAudioSchema((prev) => ({
        ...prev,
        filters: prev.filters, // ⬅️ crucial: preserve the stable ref
        [key]: updater(prev[key]),
      }));
    },
    []
  );

  const trackAudioSchemaRef = useRef(trackAudioSchema);

  useEffect(() => {
    trackAudioSchemaRef.current = trackAudioSchema;
  }, [trackAudioSchema]);

  const gainNodes = useRef<Map<number, GainNode>>(new Map());
  const panNodes = useRef<Map<number, StereoPannerNode>>(new Map());
  const highpassNodes = useRef<Map<number, BiquadFilterNode>>(new Map());
  const lowpassNodes = useRef<Map<number, BiquadFilterNode>>(new Map());

  function getTrackNode<T extends AudioNode>(
    map: Map<number, T>,
    createNode: () => T,
    key: string,
    trackId: number,
    refMap: React.RefObject<Map<string, AudioNode>>
  ): T {
    let node = map.get(trackId);
    if (!node) {
      node = createNode();
      map.set(trackId, node);
      refMap.current?.set(key, node);
    }
    return node;
  }

  const playNow = useCallback(
    async (samples: PlaybackSample[], bpm: number) => {
      await resumeAudioContext();
      const startTime = audioContext.currentTime;
      const loopLength = (60 / bpm) * beatsPerLoop;

      const buffers = await Promise.all(samples.map((s) => getSampleBuffer(s)));

      const sources = samples.map((sample, idx) => {
        const buffer = buffers[idx];
        const trackId = sample.trackId!;
        const offset = (sample.xPos ?? 0) * loopLength;

        const src = audioContext.createBufferSource();
        src.buffer = buffer;

        const {
          filters,
          bypasses,
          frequencies,
          highpassFrequencies,
          gains,
          pans,
        } = trackAudioSchemaRef.current;

        console.log(`Track ${trackId}:`);
        console.log("  Gain:", gains[trackId]);
        console.log("  Pan:", pans[trackId]);
        console.log("  Highpass Freq:", highpassFrequencies[trackId]);
        console.log("  Lowpass Freq:", frequencies[trackId]);

        const gainNode = getTrackNode(
          gainNodes.current,
          () => audioContext.createGain(),
          `${trackId}_gain`,
          trackId,
          filters
        );
        gainNode.gain.setValueAtTime(gains[trackId] ?? 1, startTime);

        const panNode = getTrackNode(
          panNodes.current,
          () => audioContext.createStereoPanner(),
          `${trackId}_pan`,
          trackId,
          filters
        );
        panNode.pan.setValueAtTime(pans[trackId] ?? 0, startTime);

        const highFilter = getTrackNode(
          highpassNodes.current,
          () => {
            const f = audioContext.createBiquadFilter();
            f.type = "highpass";
            return f;
          },
          `${trackId}_highpass`,
          trackId,
          filters
        );
        highFilter.frequency.setValueAtTime(
          highpassFrequencies[trackId] ?? 80,
          startTime
        );

        const lowFilter = getTrackNode(
          lowpassNodes.current,
          () => {
            const f = audioContext.createBiquadFilter();
            f.type = "lowpass";
            return f;
          },
          `${trackId}_lowpass`,
          trackId,
          filters
        );
        lowFilter.frequency.setValueAtTime(
          frequencies[trackId] ?? audioContext.sampleRate / 2,
          startTime
        );

        try {
          highFilter.disconnect();
        } catch {}
        try {
          lowFilter.disconnect();
        } catch {}

        let currentNode: AudioNode = src;
        currentNode.connect(gainNode);
        currentNode = gainNode;

        currentNode.connect(panNode);
        currentNode = panNode;

        if (!bypasses.highpass[trackId]) {
          currentNode.connect(highFilter);
          currentNode = highFilter;
        }

        if (!bypasses.lowpass[trackId]) {
          currentNode.connect(lowFilter);
          currentNode = lowFilter;
        }

        currentNode.connect(audioContext.destination);
        src.start(startTime + offset);
        src.stop(startTime + offset + loopLength);

        return src;
      });

      playingSources.current = sources;
    },
    [audioContext, beatsPerLoop]
  );

  const stopAll = useCallback(() => {
    playingSources.current.forEach((src) => {
      try {
        src.stop();
      } catch (e) {
        console.warn("failed to stop source", e);
      }
    });
    playingSources.current = [];
  }, []);

  return {
    playNow,
    stopAll,
    trackAudioSchema,
    updateTrackAudioSchema,
    updateAudioNodeParam,
  };
}
